import React, { Component } from 'react';

export default class Home extends Component {
    render() {
        return (
            <div color="red">
                Home Component
            </div>
        );
    }
}